package settings;

import cucumber.api.java.After;
import cucumber.api.java.en.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotSame;

public class Settings {
	
	public SettingsPage settingPage = new SettingsPage();
	
	@Given("^I am on settings page$")
	public void i_am_on_settings_page()
	{
		settingPage.gotoSettingsPage();
	}
	
	@When("^I edit SIM Nickname \"([^\"]*)\"$")
	public void I_edit_SIM_Nickname(String example)
	{
		settingPage.clickEditSIMNickname();
		settingPage.editSimNickname(example);
	}
	
	@And("^save my changes$")
	public void save_my_changes() throws InterruptedException
	{
		settingPage.saveEditSIMNickname();
	}
	
	@And("^cancel my changes$")
	public void cancel_my_changes() throws InterruptedException
	{
		settingPage.cancelEditSIMNickname();
	}
	
	@Then("^SIM nickname must be updated \"([^\"]*)\"$")
	public void sim_nickname_must_be_updated(String example)
	{
		assertEquals(example, settingPage.getSIMNicknameValue());
		//settingPage.tearDowndriver();
	}
	
	@Then("^SIM nickname must not change \"([^\"]*)\"$")
	public void SIM_nickname_must_not_change(String example)
	{
		assertNotSame(example, settingPage.getSIMNicknameValue());
		//settingPage.tearDowndriver();
	}
	
	//Call Forwarding Start
	@And("^I edit call forwarding$") //Given
	public void I_edit_call_forwarding() throws InterruptedException
	{
		settingPage.EditCallForwarding();
	}
	
	@And("^accept the terms and condition$") //Given
	public void accept_the_terms_and_condition() throws InterruptedException
	{
		settingPage.ConfirmCallForwarding();
	}
	
	@And("^input valid phone number \"([^\"]*)\"$") //When
	public void input_valid_phone_number(String example) throws InterruptedException
	{
		settingPage.InputPhoneNumber(example);
	}
	
	@And("^save my call forwarding settings$") //When
	public void save_my_call_forwarding_settings() throws InterruptedException
	{
		settingPage.SaveCallForwardingSettings();
	}
	
	@And("^cancel my call forwarding settings$")
	public void cancel_my_call_forwarding_settings()
	{
		settingPage.CancelCallForwardingSettings();
	}
	
	@And("^input invalid phone number \"([^\"]*)\"$")
	public void input_invalid_phone_number(String example) throws InterruptedException
	{
		settingPage.InputPhoneNumber(example);
	}
	
	@When("^I enable call forwarding$")
	public void I_enable_call_forwarding()
	{
		settingPage.EnableCallForwarding();
	}
	
	@When("^I disable call forwarding$")
	public void I_disable_call_forwarding()
	{
	    settingPage.DisableCallForwarding();
	}
	
	@When("^I cancel on confirmation$")
	public void I_cancel_on_confirmation()
	{
		settingPage.CancelCallForwarding();
	}
	
	@When("^I made random \"([^\"]*)\"$")
	public void I_made_random(String examples) throws InterruptedException
	{
		if (examples.equals("change phone number"))
		{
			settingPage.InputPhoneNumber("0123 456 789");
		}
		
		if (examples.equals("change status"))
		{
			settingPage.DisableCallForwarding();
		}
	}
	
	@Then("^call forwarding must be enabled$")
	public void call_forwarding_must_be_enabled()
	{
		assertEquals("Yes", settingPage.GetStatusOfCallForwarding());
	}
	
	@Then("^call forwarding must be disabled$")
	public void call_forwarding_must_be_disabled()
	{
		assertEquals("No", settingPage.GetStatusOfCallForwarding());
	}
	
	@Then("^no changes should be made$")
	public void no_changes_should_be_made()
	{
		assertEquals(settingPage.GetInitialStatusCallForwarding(), settingPage.GetStatusOfCallForwarding());
	}
	
	@Then("^i should be notified that phone number is invalid$")
	public void i_should_be_notified_that_phone_number_is_invalid()
	{
		assertEquals("Please enter your phone number in the following format: 0412 345 678 or 02 1234 5678", settingPage.GetAddPhoneNumStatus());
	}
	
	@After public void CleanUp()
	{
		settingPage.tearDowndriver();
	}
}
