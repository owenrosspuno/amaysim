package settings;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Timer;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class SettingsPage {
	
	WebDriver driver = null;
	WebDriverWait wait = null;
	
	private WebElement editSIMNicknameLink;
	private WebElement editSIMNicknameTextBox;
	private WebElement saveEditSIMNicknameButton;
	private WebElement cancelEditSIMNicknameButton;
	
	private WebElement editCallForwardingLink;
	private WebElement confirmCallForwardingButton;
	private WebElement cancelCallForwardingButton;
	private WebElement yesCallForwardingRadioButton;
	private WebElement noCallForwardingRadioButton;
	private WebElement phoneNumCallForwardingTextBox;
	private WebElement saveSettingCallForwardingButton;
	private WebElement cancelSettingCallForwardingLink;	
	private WebElement currentStatusCallForwarding;
	private String initialStatusCallForwarding;
	private String addPhoneNumStatus;
	private String parentWindowHandle;
	
	public SettingsPage() {
		
		final DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		final ChromeOptions chromeOptions = new ChromeOptions();
		
		chromeOptions.addArguments("--start-maximized");
		Map<Object, Object> prefs = new LinkedHashMap<Object, Object>();
		prefs.put("credentials_enable_service", Boolean.valueOf(false));
		prefs.put("profile.password_manager_enabled", Boolean.valueOf(false));
		chromeOptions.setExperimentalOption("prefs", prefs);
		capabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
		
		System.setProperty("webdriver.chrome.driver","c:/java/chromedriver.exe"); 
		driver = new ChromeDriver(capabilities);
		
		wait = new WebDriverWait(driver, 120);
	}
	
	public void gotoSettingsPage()
	{
		driver.navigate().to("https://accounts.amaysim.com.au/identity/login");
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("username"))).sendKeys("0468827174");
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("password"))).sendKeys("theHoff34");
		
		Actions actions = new Actions(driver);
        actions.moveToElement(wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='new_session']/button")))).sendKeys(Keys.ENTER).perform();
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='menu_list']/li[8]/a")));
		driver.navigate().to("https://www.amaysim.com.au/my-account/my-amaysim/settings");
		
		//remember parent window handle before click, because this will produce a pop-up
	    parentWindowHandle = driver.getWindowHandle();
		
		//initialStatusCallForwarding = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='settings_call_forwarding']/div/div/div[2]"))).toString();
		initialStatusCallForwarding = GetStatusOfCallForwarding();
	}
	
	public void clickEditSIMNickname()
	{
		editSIMNicknameLink= wait.until(ExpectedConditions.elementToBeClickable(By.id("edit_settings_phone_label")));
		editSIMNicknameLink.click();
	}
	
	public void editSimNickname(String newValue)
	{
		editSIMNicknameTextBox = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("my_amaysim2_setting_phone_label")));
		editSIMNicknameTextBox.clear();
		editSIMNicknameTextBox.sendKeys(newValue);
	}
	
	public void saveEditSIMNickname() throws InterruptedException
	{
		saveEditSIMNicknameButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#edit_settings_sim_nickname > div.row.border-top.padding-top > div > input")));
		
		Actions actions = new Actions(driver);
        Thread.sleep(3000);
		actions.moveToElement(saveEditSIMNicknameButton).click().perform();
	}
	
	public void cancelEditSIMNickname() throws InterruptedException
	{
		cancelEditSIMNicknameButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("show_settings_sim_nickname")));
		Actions actions = new Actions(driver);
        Thread.sleep(3000);
		actions.moveToElement(cancelEditSIMNicknameButton).click().perform();
	}
	
	public String getSIMNicknameValue()
	{
		WebElement currentSIMNicknameValue = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='settings_sim_nickname']/div/div[1]/div/div[2]")));
		return currentSIMNicknameValue.getText();
	}
	
	//Call Forwarding
	public void EditCallForwarding()
	{
		//remember parent window handle before click, because this will produce a pop-up
	    //parentWindowHandle = driver.getWindowHandle();
		
		editCallForwardingLink = wait.until(ExpectedConditions.elementToBeClickable(By.id("edit_settings_call_forwarding")));

        JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].scrollIntoView();", editCallForwardingLink);
		
		Actions actions = new Actions(driver);
        actions.moveToElement(editCallForwardingLink).click().perform();
    }
	
	//Call Forwarding
	public void ConfirmCallForwarding() throws InterruptedException
	{
		int handleCounter = 0;
		
		for(String winHandle : driver.getWindowHandles()){
		    driver.switchTo().window(winHandle);
		    handleCounter++;
		}
		
		confirmCallForwardingButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#body-content > div.form_confirm_popup.reveal-modal.padding-none.open > div > div > div > div.small-6.columns.padding-left > a")));

        //Actions actions = new Actions(driver);
        //actions.moveToElement(confirmCallForwardingButton).sendKeys(Keys.ENTER).perform();
		
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click();", confirmCallForwardingButton);
		
        //driver.close();
		driver.switchTo().window(parentWindowHandle);
	}
	
	//Call Forwarding
	public void CancelCallForwarding()
	{
		cancelCallForwardingButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='body-content']/div[16]/div/div/div/div[2]/a")));
		//cancelCallForwardingButton.click();
		Actions actions = new Actions(driver);
        actions.moveToElement(cancelCallForwardingButton).sendKeys(Keys.ENTER).perform();
	}
	
	//Call Forwarding
	public void EnableCallForwarding()
	{
		yesCallForwardingRadioButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='update_call_forwarding_form']/div[2]/div/label[1]/span")));

        Actions actions = new Actions(driver);
        //actions.moveToElement(yesCallForwardingRadioButton).click().perform();
        actions.moveToElement(yesCallForwardingRadioButton).sendKeys(Keys.ENTER).perform();
	}
	
	//Call Forwarding
    public void DisableCallForwarding()
	{
    	noCallForwardingRadioButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='update_call_forwarding_form']/div[2]/div/label[2]/span")));
    	//noCallForwardingRadioButton.click();
    	
    	//Actions actions = new Actions(driver);
        //actions.moveToElement(noCallForwardingRadioButton).click().perform();
    	//actions.moveToElement(noCallForwardingRadioButton).sendKeys(Keys.ENTER).perform();
    	
    	JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click();", noCallForwardingRadioButton);
	}	
    
    //Call Forwarding
    public void InputPhoneNumber(String value) throws InterruptedException
    {
    	//phoneNumCallForwardingTextBox = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='my_amaysim2_setting_call_divert_number']")));
    	phoneNumCallForwardingTextBox = wait.until(ExpectedConditions.elementToBeClickable(By.id("my_amaysim2_setting_call_divert_number")));
    	
    	//Thread.sleep(3000);
    	
    	phoneNumCallForwardingTextBox.clear();
    	phoneNumCallForwardingTextBox.sendKeys(value);
   }
    
    //Call Forwarding
    public void SaveCallForwardingSettings() throws InterruptedException
    {
    	//saveSettingCallForwardingButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='update_call_forwarding_form']/div[4]/div/input")));
    	saveSettingCallForwardingButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#update_call_forwarding_form > div.row.border-top.padding-top.margin-top > div > input")));
    	
    	Actions actions = new Actions(driver);
        actions.moveToElement(saveSettingCallForwardingButton).sendKeys(Keys.ENTER).perform();
        
        Thread.sleep(3000);
        
        JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("arguments[0].click();", saveSettingCallForwardingButton);
    }
    
    //Call Forwarding
    public void CancelCallForwardingSettings()
    {
    	cancelSettingCallForwardingLink = wait.until(ExpectedConditions.elementToBeClickable(By.id("cancel_settings_call_forwarding")));
    	cancelSettingCallForwardingLink.click();
    }
    
    //Call Forwarding
    public String GetStatusOfCallForwarding()
    {
    	driver.switchTo().window(parentWindowHandle);
    	
    	currentStatusCallForwarding = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='settings_call_forwarding']/div/div[1]/div[2]")));
    	return currentStatusCallForwarding.getText();
    }
    
    public String GetAddPhoneNumStatus()
    {
    	addPhoneNumStatus = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='settings_divert_number']/span"))).getText();
        return addPhoneNumStatus;
    }
    
    public String GetInitialStatusCallForwarding()
    {
    	return initialStatusCallForwarding;
    }
	
	public void tearDowndriver()
	{
		driver.close();
	}
}